public class Card {

    private String cardVal;
    public String getCarVal(){
      return cardVal;
    }

    public Card() {
      int deck = (int)(Math.random()*CardUtil.SUIT.length);// 0,1
      int suit = (int)(Math.random()*CardUtil.VALU.length);// 0~9
      //임의의 카드값을 갖는다
      cardVal = CardUtil.SUIT[deck] + CardUtil.VALU[suit];
  }

    public Card(String s) {
      this.cardVal = s; //문자열 값 복사
    }

    public Card(Card c) {
      this(c.getCardVal());
    }
 
}