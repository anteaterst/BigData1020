//new 로 생성한 객체는 해시코드 값이 모두 다르다. 같을 수 없다. 같은 값을 가진 카드라도 카드1.equals(카드2)는 false (vs ==)\
//그래서 같은 값을 가지면 같은 객체로 만들어야 할때 euals()오버라디딩을 한다. 예로 수학 좌표에서 P1(1,2)과 P2(1,2) 같은 위치 (1==1), (2==2) 하지만 프로그래밍에서는 다른 객체가 된다. 
// 같은 객체로 만들기 위해서는 오버라이딩 해야 된다. 


public class Main {
	public static void main(String[] args) {
		Card c1=new Card("H4");               // 생성자 (String 아규먼트)
		Card c2=new Card("H4");               // 생성자 (String 아규먼트)
        System.out.println(c1.hashCode());    // 값은 동일 같은 해쉬
        System.out.println(c2.hashCode());    // 값은 동일 같은 해쉬
        System.out.println(c1.getCardVal());  // 값은 동일
        System.out.println(c2.getCardVal());  // 값은 동일
        System.out.println(c1.equals(c2));    // hashCode 비교- 오버라이딩- 중요
        // 같은 값을 갖을 때 같은 객체로 정의하고 싶다면 
        // hashCode(), equals()를 오버라이딩하자.
	}
}
