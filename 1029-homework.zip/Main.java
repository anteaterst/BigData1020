// 첫번째 정수가 0인지 1인지를 확인하여 a와 b로 나눈다
// 경우 a와 b를 각자 문자열의 갯수만큼
// 
// 

import java.util.*;

class Main {
  public static int a;
  public static int b;
  public static String s;
  public static void main(String[] args) {

    Scanner sc = new Scanner(System.in);
  
    s = sc.next();
    
  
    if(s.charAt(0) == '1') {
      a += 1;}
      else{
      b += 1;
      }

    
      for (int i = 0; i < s.length() - 1; i++){
        if(s.charAt(i) != s.charAt(i + 1)) {
          if(s.charAt(i + 1) == '1') a += 1;
            else b += 1;
        }
      }
    
    System.out.println(Math.min(a,b));
  }
}
