class Main {
  public static void main(String[] args) {
    String[] names = {"Cm","M","Inch","Feet","Yard","Mile"};

    for(int i = 0; i < names.length; i++){
      System.out.printf("%s\t",names[i]);
    }
    
    for(String ss:names){
      System.out.printf("%s\t",ss);
    }

  }
}